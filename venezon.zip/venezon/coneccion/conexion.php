<?php

$usuario_db = 'root';
$contrasena_db = 'mini2019';
$pdo_conn = new PDO( 'mysql:host=localhost;dbname=venezon', $usuario_db, $contrasena_db );

?>