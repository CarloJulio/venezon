<title>Comercial El Zorro - Mensaje 1</title>
<link rel="shortcut icon" href="avatar.png" />
<div style="margin-top:20px; margin-left:20px;"> 
<p style="font-family: Arial; font-size: 15pt;">Comercial Santa Ana</p>
<a href=<?php echo "../index.php" ?> style="font-family: Arial; font-size: 15pt;">ir a la p&#225gina Inicio</a>
</div>